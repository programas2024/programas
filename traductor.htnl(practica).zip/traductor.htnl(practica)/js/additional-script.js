// Función para generar la traducción usando la API de Google Translate
async function generateSummary() {
    const originalText = document.getElementById('originalText').value;
    const selectedLanguage = document.getElementById('selectLanguage').value;

    // Comprobar si el campo de texto a traducir no está vacío
    if (originalText.trim() === '') {
        document.getElementById('errorMessage').innerText = 'Por favor, ingresa el texto que deseas traducir.';
        return;
    }

    try {
        const apiUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${selectedLanguage}&dt=t&q=${encodeURIComponent(originalText)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        // La traducción se encuentra en data[0][0][0]
        const translatedText = data[0][0][0];
        document.getElementById('summaryText').value = translatedText;

        // Llamar a la función para mostrar los detalles de la traducción
        showTranslationDetails(originalText, translatedText, selectedLanguage);
    } catch (error) {
        console.error('Error al traducir:', error);
        document.getElementById('errorMessage').innerText = 'Hubo un error al traducir el texto. Por favor, intenta de nuevo.';
    }
}

// Función para mostrar detalles de la traducción
function showTranslationDetails(originalText, translatedText, language) {
    const words = translatedText.split(' ');
    const pronunciation = words.map(word => getPronunciation(word, language)).join(' ');

    document.getElementById('translationDetails').innerHTML = `
        <h3>Detalles de la Traducción:</h3>
        <p><strong>Texto Original:</strong> ${originalText}</p>
        <p><strong>Texto Traducido:</strong> ${translatedText}</p>
        
        <p><strong>Pronunciación en ${language}:</strong> ${pronunciation}</p>
    `;
}

// Función para obtener la "pronunciación" de una palabra en el idioma seleccionado
function getPronunciation(word, language) {
    // Simulación de una pronunciación legible para el idioma seleccionado
    return `[${word.split('').join('-')}]`; // Ejemplo simple, puedes ajustarlo según el idioma
}

// Función para traducir mediante sonido (simulación)
function translateSound() {
    // Simulación: se tomaría el input de voz y se usaría para llenar los campos de texto
    const originalText = "Texto de ejemplo capturado por sonido";
    document.getElementById('originalText').value = originalText;
    generateSummary();  // Llama a la función de traducción directamente después de capturar el sonido
}

