function updateWordCount() {
    const originalText = document.getElementById('originalText').value.trim();
    const wordCount = originalText ? originalText.split(/\s+/).filter(word => word).length : 0;
    document.getElementById('originalWordCount').textContent = `${wordCount} palabras`;
}

// Función para generar el resumen traducido
function generateSummary() {
    const originalText = document.getElementById('originalText').value.trim();
    const selectedLanguage = document.getElementById('selectLanguage').value;

    // Lógica de traducción usando la API de Google Translate
    const apiUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${selectedLanguage}&dt=t&q=${encodeURIComponent(originalText)}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            let translatedText = '';

            // Recorrer todas las partes traducidas del texto
            data[0].forEach(part => {
                translatedText += part[0]; // Concatenar cada parte traducida
            });

            // Actualizar el área de resumen con el texto traducido completo
            document.getElementById('summaryText').value = translatedText;
            // Actualizar el conteo de palabras del resumen
            document.getElementById('summaryWordCount').textContent = `${translatedText.split(/\s+/).length} palabras`;
        })
        .catch(error => console.error('Error en la traducción:', error));
}

function copySummary() {
    const summaryText = document.getElementById('summaryText');
    summaryText.select();
    document.execCommand('copy');
    alert('Resumen copiado al portapapeles.');
}

// Función para leer en voz alta el resumen
function speakSummary() {
    const summary = document.getElementById('summaryText').value;

    // Verificar si el navegador soporta la síntesis de voz
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(summary);
        speechSynthesis.speak(utterance);
    } else {
        alert('Tu navegador no soporta la síntesis de voz.');
    }
}

// Función para redirigir a la página principal
function goToIndex() {
    window.location.href = 'index.html';
}

// Función para mostrar y ocultar el menú desplegable
function toggleDropdown() {
    const dropdown = document.getElementById('dropdownMenu');
    dropdown.classList.toggle('show');
}


